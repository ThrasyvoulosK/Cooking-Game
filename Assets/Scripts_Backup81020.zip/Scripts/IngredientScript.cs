﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class IngredientScript : MonoBehaviour
{
   
    BoxCollider2D boxCollider2D;


    //Drag And Drop Variables And Functions
    /*bool mouseisheld = false;*/

    //current mouse position coordinates
    Vector2 mouseposition;

    float initialmousepositionX;
    float initialmousepositionY;

    public FurnaceScript theFurnace;
    public SpawningScript theSpawning;

    public ChangeSceneScript theChangeScene;

    GameObject target;
    Vector2 directiontotarget;

    void Start()
    {
        boxCollider2D = GetComponent<BoxCollider2D>();

        //furnace needs this as a reference
        theFurnace = GameObject.Find("Furnace").GetComponent<FurnaceScript>();
        //also spawning
        theSpawning = GameObject.Find("SpawningPoint").GetComponent<SpawningScript>();

        //the ingredients should fly towards this, if correct
        target = null;
        //target = GameObject.Find("Furnace");

        theChangeScene = GameObject.Find("Canvas").GetComponent<ChangeSceneScript>();
    }
    // Update is called once per frame
    void Update()
    {
        /*if(mouseisheld)
        {
            //position in-game
            mouseposition = Input.mousePosition;
            //position from the player's POV
            mouseposition = Camera.main.ScreenToWorldPoint(mouseposition);

            this.gameObject.transform.localPosition = new Vector2(mouseposition.x-initialmousepositionX, mouseposition.y-initialmousepositionY);

        }*/
        /*else
        {*/
        //keep moving
        if (gameObject.name.Contains("Clone"))
        {
            transform.Translate(Vector2.right * Time.deltaTime*2);
            if (gameObject.transform.position.x >10)
            {
                Destroy(gameObject);
                //theSpawning.spawnallowed = true;
            }
        }
        //TOP-DOWN VERSION
        /*
        if (gameObject.name.Contains("Clone"))
        {
            transform.Translate(Vector2.down * Time.deltaTime * 2);
            if (gameObject.transform.position.y < -5)
            {
                Destroy(gameObject);
                theSpawning.spawnallowed = true;
            }

        }*/

        /*}*/

        MoveIngredient();

    }

    //this iterator holds the number of the current recipe
    //it gets +1 when we are finished with it
    /*public int iterator = 0;*/

    bool notnullrecipeexists;

    public void OnMouseDown()
    {
        //Vector2 mouseposition;

        //boxCollider2D.enabled = false;


        //Debug.Log("onmousedown");
        //transform.position= Camera.main.ScreenToWorldPoint(Input.mousePosition); //this centers it, but disregards initial position
        //same as above
        /*mouseposition = Input.mousePosition;
        mouseposition = Camera.main.ScreenToWorldPoint(mouseposition);

        //keep the initial mouse positions so as to avoid changing an object's movement by a simple click
        initialmousepositionX = mouseposition.x - this.transform.localPosition.x;
        initialmousepositionY = mouseposition.y - this.transform.localPosition.y;

        mouseisheld = true;*/

        //repalcing previoous functionality
        //WORK IN PROGRESS!
        //rename our object so that it is usable within recipes
        gameObject.name = gameObject.name.Substring(0, gameObject.name.Length - 7);//remove (clone) from string

        //add to current recipe
        theFurnace.current_recipe.Add(gameObject.name);

        bool ingredientisonthelist = false;
        //remove from the correct igredient from the numbers list
        int i = 0;
        Debug.Log("begore loops");
        foreach (string checkingr in theFurnace.recipe.neededIngr)
        {
            if (checkingr == gameObject.name)
            {
                //assign to the correct number
                theFurnace.usable_number_of_ingredients[i]--;
                ingredientisonthelist = true;
                target = GameObject.Find("Furnace");
                break;
            }
            i++;
        }

        i = 0;
        Debug.Log("before second loop");
        foreach (int correctingr in theFurnace.usable_number_of_ingredients)
        {

            int it = 0;

            Debug.Log("within second loop");
            if (correctingr <= 0)
            {
                //Debug.Log("fully completed ingredient"+theFurnace.recipe.neededIngr[correctingr]);
                i++;
            }
            if (i == theFurnace.recipe.neededIngr.Count)
            {
                //WINNING CONDITION
                Debug.Log("recipe ready!");
                //reset currentrecipe list
                theFurnace.current_recipe.Clear();
                //Debug.Log("iterator " + iterator);
                if (theFurnace.next_recipe!=null)
                {
                    //theFurnace.recipe = theFurnace.next_recipe[iterator];
                    //theFurnace.recipe = theFurnace.next_recipe[1];
                    //iterator++;
                    /*theFurnace.recipe = theFurnace.next_recipe[iterator];*/

                    /*
                    theFurnace.next_recipe[0] = null;
                    theFurnace.next_recipe[0] = theFurnace.next_recipe[1];
                    theFurnace.next_recipe[1] = null;
                    theFurnace.recipe = theFurnace.next_recipe[0];*/

                    //search for a non-null recipe in the nextrecipes lists
                    
                    foreach(Recipe_SO nrec in theFurnace.next_recipe)
                    {
                        if(nrec!=null)
                        {
                            //theFurnace.next_recipe[0] = nrec;
                            theFurnace.recipe = theFurnace.next_recipe[it]; //nrec;

                            //


                            //
                            theFurnace.recipe.numbOfIng = theFurnace.next_recipe[it].numbOfIng;//
                            theFurnace.recipe.neededIngr = theFurnace.next_recipe[it].neededIngr;//
                            theFurnace.recipe = theFurnace.next_recipe[it];
                            //

                            theFurnace.next_recipe[it] = null;

                            break;

                        }
                        it++;
                        if(it==theFurnace.next_recipe.Length)
                        {
                            Debug.Log("all recipes done");
                            //copy pasted from down
                            Debug.Log("win");
                            theChangeScene.change_scene();
                        }

                    }
                    //iterator++;
                    //iterator = iterator + 1;
                    Debug.Log("curent recipes first ingredient" + theFurnace.recipe.neededIngr[0]);
                    //Debug.Log("iterator " + iterator);
                    //iterator = iterator + 1;
                    //Debug.Log("iterator " + iterator);

                    //change the next recipe
                    Debug.Log("next recipe length " + theFurnace.next_recipe.Length);
                    //if(theFurnace.next_recipe.Length==null)
                    /*if (iterator >= theFurnace.next_recipe.Length)
                    {
                        theFurnace.next_recipe = null;
                        Debug.Log("iterator next");
                    }*/
                }
                else
                {
                    Debug.Log("win");
                    theChangeScene.change_scene();
                    //theChangeScene.change_sceneplus2();
                    
                    //Application.Quit();
                }

                /*
                //change the next recipe
                Debug.Log("next recipe length " + theFurnace.next_recipe.Length);
                //if(theFurnace.next_recipe.Length==null)
                if (iterator > theFurnace.next_recipe.Length)
                {
                    theFurnace.next_recipe = null;
                    Debug.Log("iterator next");
                }
                */    

                theFurnace.usable_number_of_ingredients.Clear();
                //
                /* theFurnace.recipe.numbOfIng = theFurnace.next_recipe[iterator].numbOfIng;//
                 theFurnace.recipe.neededIngr = theFurnace.next_recipe[iterator].neededIngr;//*/
                //iterator+=1;//
                //
                /*
                theFurnace.recipe.numbOfIng = theFurnace.next_recipe[0].numbOfIng;//
                theFurnace.recipe.neededIngr = theFurnace.next_recipe[0].neededIngr;//
                theFurnace.recipe = theFurnace.next_recipe[0];*/
                Debug.Log("it: " + it);
                /*theFurnace.recipe.numbOfIng = theFurnace.next_recipe[it].numbOfIng;//
                theFurnace.recipe.neededIngr = theFurnace.next_recipe[it].neededIngr;//
                theFurnace.recipe = theFurnace.next_recipe[it];*/

                Debug.Log("next recipe");

                /*iterator += 1;//*/
                foreach (int j in theFurnace.recipe.numbOfIng)
                {
                    theFurnace.usable_number_of_ingredients.Add(j);
                    //break;
                }
                //
                break;

            }
            //else
            // Debug.Log("we still need ingredients");//+ theFurnace.recipe.neededIngr)
        }
        //destroy only if it is on the list
        if (ingredientisonthelist == true)
        { 
            //Destroy(gameObject);
        }
        else
        {
            //remove from the current list if not needed
            theFurnace.current_recipe.Remove(gameObject.name);

            Debug.Log("object not on list");

            //rename it back to its original name
            //(this is a workaround for allowing only "(clones)" to move!
            gameObject.name += "(Clone)";

            
        }

        //when we destroy an object, we can instantiate the next one
        theSpawning.spawnallowed = true;

    }

    void MoveIngredient()
    {
        if(target!=null)
        {
            directiontotarget = (target.transform.position - transform.position).normalized;
            //GetComponent<Rigidbody2D>().velocity = new Vector2(directiontotarget.x * Time.deltaTime * 2, directiontotarget.y * Time.deltaTime * 2);
            GetComponent<Rigidbody2D>().velocity = new Vector2(directiontotarget.x *  2, directiontotarget.y *  2);
        }
        //

    }

    public void OnMouseUp()
    {
        //Debug.Log("mouseup");
        /*mouseisheld = false;
        boxCollider2D.enabled = true;*/
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        //Debug.Log("collision with "+ collision.gameObject.name);
        //Destroy(collision.gameObject);
        //Destroy(self)
    }

    int numofequals = 0;

    public void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name=="Furnace")
        {
            Destroy(gameObject);
        }
        //Debug.Log("collision of " + gameObject.name+" with "+collision.name);
    }
    /*
    public void OnTriggerEnter2D(Collider2D collision)
    {
        
        //Debug.Log("trigger collision with " + collision.gameObject.name);
       if(collision.gameObject.name=="Furnace")
        {

            //rename our object so that it is usable within recipes
            gameObject.name = gameObject.name.Substring(0,gameObject.name.Length - 7);//remove (clone) from string

            //add to current recipe
            theFurnace.current_recipe.Add(gameObject.name);
            
            //remove from the correct igredient from the numbers list
            int i = 0;
            foreach(string checkingr in theFurnace.recipe.neededIngr)
            {
                if(checkingr==gameObject.name)
                {
                    //assign to the correct number
                    theFurnace.usable_number_of_ingredients[i]--;
                    break;
                }
                i++;
            }

            i = 0;
            foreach(int correctingr in theFurnace.usable_number_of_ingredients)
            {
                if(correctingr<=0)
                {
                    //Debug.Log("fully completed ingredient"+theFurnace.recipe.neededIngr[correctingr]);
                    i++;
                }
                if (i == theFurnace.recipe.neededIngr.Count)
                    Debug.Log("recipe ready!");
                //else
                   // Debug.Log("we still need ingredients");//+ theFurnace.recipe.neededIngr)
            }
            //TESTING DESTROY
            Destroy(gameObject);
        
        }
    }
    //end
    */

}
