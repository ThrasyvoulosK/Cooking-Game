﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
public class IngredientScript : MonoBehaviour
{
   
    BoxCollider2D boxCollider2D;


    //Drag And Drop Variables And Functions
    /*bool mouseisheld = false;*/

    //current mouse position coordinates
    Vector2 mouseposition;

    float initialmousepositionX;
    float initialmousepositionY;

    public FurnaceScript theFurnace;
    public SpawningScript theSpawning;

    void Start()
    {
        boxCollider2D = GetComponent<BoxCollider2D>();

        //furnace needs this as a reference
        theFurnace = GameObject.Find("Furnace").GetComponent<FurnaceScript>();
        //also spawning
        theSpawning = GameObject.Find("SpawningPoint").GetComponent<SpawningScript>();
    }
    // Update is called once per frame
    void Update()
    {
        /*if(mouseisheld)
        {
            //position in-game
            mouseposition = Input.mousePosition;
            //position from the player's POV
            mouseposition = Camera.main.ScreenToWorldPoint(mouseposition);

            this.gameObject.transform.localPosition = new Vector2(mouseposition.x-initialmousepositionX, mouseposition.y-initialmousepositionY);

        }*/
        /*else
        {*/
        //keep moving
        /*if(gameObject.name.Contains("Clone"))
            transform.Translate(Vector2.right * Time.deltaTime);*/
        //TOP-DOWN VERSION
        if (gameObject.name.Contains("Clone"))
        {
            transform.Translate(Vector2.down * Time.deltaTime * 2);
            if (gameObject.transform.position.y < -5)
            {
                Destroy(gameObject);
                theSpawning.spawnallowed = true;
            }

        }
            
        /*}*/

    }
    public void OnMouseDown()
    {
        //Vector2 mouseposition;
        boxCollider2D.enabled = false;
        //Debug.Log("onmousedown");
        //transform.position= Camera.main.ScreenToWorldPoint(Input.mousePosition); //this centers it, but disregards initial position
        //same as above
        /*mouseposition = Input.mousePosition;
        mouseposition = Camera.main.ScreenToWorldPoint(mouseposition);

        //keep the initial mouse positions so as to avoid changing an object's movement by a simple click
        initialmousepositionX = mouseposition.x - this.transform.localPosition.x;
        initialmousepositionY = mouseposition.y - this.transform.localPosition.y;

        mouseisheld = true;*/

        //repalcing previoous functionality
        //WORK IN PROGRESS!
        //rename our object so that it is usable within recipes
        gameObject.name = gameObject.name.Substring(0, gameObject.name.Length - 7);//remove (clone) from string

        //add to current recipe
        theFurnace.current_recipe.Add(gameObject.name);

        //remove from the correct igredient from the numbers list
        int i = 0;
        foreach (string checkingr in theFurnace.recipe.neededIngr)
        {
            if (checkingr == gameObject.name)
            {
                //assign to the correct number
                theFurnace.usable_number_of_ingredients[i]--;
                break;
            }
            i++;
        }

        i = 0;
        foreach (int correctingr in theFurnace.usable_number_of_ingredients)
        {
            if (correctingr <= 0)
            {
                //Debug.Log("fully completed ingredient"+theFurnace.recipe.neededIngr[correctingr]);
                i++;
            }
            if (i == theFurnace.recipe.neededIngr.Count)
                Debug.Log("recipe ready!");
            //else
            // Debug.Log("we still need ingredients");//+ theFurnace.recipe.neededIngr)
        }
        //TESTING DESTROY
        Destroy(gameObject);

        //when we destroy an object, we can instantiate the next one
        //SpawningScript.spawnallowed = true;
        theSpawning.spawnallowed = true;

    }

    public void OnMouseUp()
    {
        //Debug.Log("mouseup");
        /*mouseisheld = false;
        boxCollider2D.enabled = true;*/
    }

    public void OnCollisionEnter2D(Collision2D collision)
    {
        //Debug.Log("collision with "+ collision.gameObject.name);
        //Destroy(collision.gameObject);
        //Destroy(self)
    }

    int numofequals = 0;
    /*
    public void OnTriggerEnter2D(Collider2D collision)
    {
        
        //Debug.Log("trigger collision with " + collision.gameObject.name);
       if(collision.gameObject.name=="Furnace")
        {

            //rename our object so that it is usable within recipes
            gameObject.name = gameObject.name.Substring(0,gameObject.name.Length - 7);//remove (clone) from string

            //add to current recipe
            theFurnace.current_recipe.Add(gameObject.name);
            
            //remove from the correct igredient from the numbers list
            int i = 0;
            foreach(string checkingr in theFurnace.recipe.neededIngr)
            {
                if(checkingr==gameObject.name)
                {
                    //assign to the correct number
                    theFurnace.usable_number_of_ingredients[i]--;
                    break;
                }
                i++;
            }

            i = 0;
            foreach(int correctingr in theFurnace.usable_number_of_ingredients)
            {
                if(correctingr<=0)
                {
                    //Debug.Log("fully completed ingredient"+theFurnace.recipe.neededIngr[correctingr]);
                    i++;
                }
                if (i == theFurnace.recipe.neededIngr.Count)
                    Debug.Log("recipe ready!");
                //else
                   // Debug.Log("we still need ingredients");//+ theFurnace.recipe.neededIngr)
            }
            //TESTING DESTROY
            Destroy(gameObject);
        
        }
    }
    //end
    */

}
