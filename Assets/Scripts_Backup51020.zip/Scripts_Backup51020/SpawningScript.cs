﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SpawningScript : MonoBehaviour
{
    bool spawnallowed = true;//

    public GameObject[] ingredients;

    public Transform[] spawnpoints;

    // Start is called before the first frame update
    void Start()
    {
        InvokeRepeating("SpawnIngredient", 1, 1);
        
    }
    /*
    // Update is called once per frame
    void Update()
    {
        
    }
    */
    void SpawnIngredient()
    {
        int randomingredient;
        randomingredient = Random.Range(0, ingredients.Length);
        //Instantiate(ingredients[1],spawnpoints[0].position,Quaternion.identity);
        Instantiate(ingredients[randomingredient], spawnpoints[0].position, Quaternion.identity);
    }
}
