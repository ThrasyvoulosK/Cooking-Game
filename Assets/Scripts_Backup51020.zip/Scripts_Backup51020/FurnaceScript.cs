﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class FurnaceScript : MonoBehaviour
{
    //public GameObject[] recipe;
    //public recipe allrecipes;

    /* public List<List<GameObject>> recipeslist;// = new List<List<GameObject>>();
     public List<GameObject> onesuchrecipe;*/
    //public List<GameObject> oneothersuchrecipe;
    public List<string> oneothersuchrecipe;

    public List<List<string>> recipeslist;
    public List<string> onesuchrecipe;

    public Recipe_SO recipe;
    //our current, in-game recipe
    //public List<gamobject> current_recipe;
    public List<string> current_recipe;

    public List<int> current_number_of_ingredients=new List<int>();
    // Start is called before the first frame update
    void Start()
    {
        /*recipeslist = new List<List<GameObject>>();
        onesuchrecipe = new List<GameObject>();*/
        /*recipeslist = new List<List<string>>();
        onesuchrecipe = new List<string>();

        //
       // onesuchrecipe.Add("Ingredient (1)");
       // onesuchrecipe.Add("Ingredient (2)");

     


        recipeslist.Add(onesuchrecipe);
        recipeslist.Insert(0, onesuchrecipe);

        //oneothersuchrecipe= new List<GameObject>();
        Debug.Log(onesuchrecipe[0]);// + onesuchrecipe[1]);
        */


        //recipe.

    }

    // Update is called once per frame
    void Update()
    {
        
    }
}
